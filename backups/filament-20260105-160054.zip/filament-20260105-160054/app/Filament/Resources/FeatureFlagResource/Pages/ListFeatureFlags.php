<?php

declare(strict_types=1);

namespace App\Filament\Resources\FeatureFlagResource\Pages;

use App\Filament\Pages\Support\BaseListRecords;
use App\Filament\Resources\FeatureFlagResource;
use Filament\Actions\CreateAction;

class ListFeatureFlags extends BaseListRecords
{
    protected static string $resource = FeatureFlagResource::class;

    protected function getHeaderActions(): array
    {
        return [
            CreateAction::make(),
        ];
    }
}
