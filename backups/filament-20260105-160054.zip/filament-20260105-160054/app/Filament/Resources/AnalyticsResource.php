<?php

declare(strict_types=1);

namespace App\Filament\Resources;

use App\Enums\OrderStatus;
use App\Filament\Resources\AnalyticsResource\Pages;
use App\Models\Order;
use App\Support\Filament\Components\Flatpickr as SupportFlatpickr;
use App\Support\Filament\Filters\DateRangeFilter;
use Filament\Actions\ViewAction;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Tables\Columns\Summarizers\Average;
use Filament\Tables\Columns\Summarizers\Count;
use Filament\Tables\Columns\Summarizers\Sum;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\Filter;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Grouping\Group;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use LaraZeus\SpatieTranslatable\Resources\Concerns\Translatable as SpatieTranslatableResource;

final class AnalyticsResource extends Resource
{
    use SpatieTranslatableResource;  // Align translation support with other resources.

    /**
     * Anchor the resource to the Order model so Filament resolves queries without inferring a non-existent Analytics model.
     */
    protected static ?string $model = Order::class;

    // Use base Resource properties for navigation icon/group to avoid type conflicts in PHP.

    public static function getNavigationLabel(): string
    {
        // Surface the dashboard-specific label to match the refreshed navigation copy.
        return __('analytics.analytics_dashboard');
    }

    public static function getModelLabel(): string
    {
        return __('analytics.analytics');
    }

    public static function getPluralModelLabel(): string
    {
        return __('analytics.analytics');
    }

    public static function canAccess(): bool
    {
        return true;
    }

    public static function getNavigationBadge(): ?string
    {
        $count = (int) Order::query()->where('status', 'pending')->count();

        return $count > 0 ? (string) $count : null;
    }

    public static function getNavigationBadgeColor(): string
    {
        return 'warning';
    }

    public static function form(Schema $schema): Schema
    {
        return $schema;
    }

    public static function table(Table $table): Table
    {
        // Configure the table definition for the streamlined Filament v4 return type.
        return $table
            // Preload frequently accessed relationships so table metrics do not suffer from N+1 queries.
            ->modifyQueryUsing(
                static fn (Builder $query): Builder => $query
                    ->select([
                        'id',
                        'number',
                        'user_id',
                        'channel_id',
                        'status',
                        'total',
                        'created_at',
                        'updated_at',
                    ])
                    ->with([
                        'user:id,name,email',
                        'channel:id,name',
                    ])
            )
            ->columns([
                // Order number helps link analytics rows back to operational records.
                TextColumn::make('number')
                    ->label(__('analytics.order_number'))
                    ->searchable()
                    ->sortable()
                    ->toggleable()
                    ->summarize([
                        Count::make()->label(__('analytics.total_orders')),
                    ]),
                // Preserve the localized order date column but keep the explicit accessor for clarity.
                TextColumn::make('order_date')
                    ->label(__('analytics.columns.order_date'))
                    ->date()
                    ->sortable()
                    ->getStateUsing(static fn (Order $record) => $record->created_at)
                    ->toggleable(),
                // Show the purchasing customer's name for segmentation.
                TextColumn::make('user.name')
                    ->label(__('analytics.customer'))
                    ->searchable()
                    ->sortable()
                    ->toggleable(),
                // Provide the customer's email to support outreach workflows directly from analytics.
                TextColumn::make('user.email')
                    ->label(__('analytics.customer_email'))
                    ->searchable()
                    ->toggleable(),
                // Channel names aid in marketing attribution when reviewing performance.
                TextColumn::make('channel.name')
                    ->label(__('analytics.channel'))
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                // Count items via a relationship aggregate to avoid loading full item rows.
                TextColumn::make('items_count')
                    ->label(__('analytics.items'))
                    ->counts('items')
                    ->toggleable(),
                // Total revenue column contributes to aggregate KPIs.
                TextColumn::make('total')
                    ->label(__('analytics.total'))
                    ->money('EUR')
                    ->sortable()
                    ->toggleable()
                    ->summarize([
                        Sum::make('total')->label(__('analytics.total_revenue'))->money('EUR'),
                        Average::make('total')->label(__('analytics.avg_order_value'))->money('EUR'),
                    ]),
                // Translate status badges so the dashboard remains localized.
                TextColumn::make('status')
                    ->label(__('analytics.status'))
                    ->sortable()
                    ->badge()
                    ->formatStateUsing(static function (OrderStatus|string $state): string {
                        // Normalise enum-backed states into simple translation keys before rendering.
                        $value = $state instanceof OrderStatus ? $state->value : $state;

                        return __('analytics.' . strtolower($value));
                    })
                    ->color(static function (OrderStatus|string $state): string {
                        // Reuse the normalised value so badge colours remain stable for enums and raw strings alike.
                        $value = $state instanceof OrderStatus ? $state->value : $state;

                        return match ($value) {
                            'completed', 'delivered' => 'success',
                            'pending' => 'warning',
                            'cancelled', 'refunded' => 'danger',
                            default => 'gray',
                        };
                    })
                    ->toggleable(),
                // Maintain timestamps for auditing and allow toggling visibility per user preference.
                TextColumn::make('created_at')
                    ->label(__('analytics.created'))
                    ->dateTime()
                    ->sortable()
                    ->toggleable(),
                TextColumn::make('updated_at')
                    ->label(__('analytics.updated'))
                    ->dateTime()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                SelectFilter::make('status')
                    ->label(__('analytics.status'))
                    ->options([
                        'pending'    => __('analytics.pending'),
                        'processing' => __('analytics.processing'),
                        'completed'  => __('analytics.completed'),
                        'cancelled'  => __('analytics.cancelled'),
                        'shipped'    => __('analytics.shipped'),
                        'delivered'  => __('analytics.delivered'),
                        'refunded'   => __('analytics.refunded'),
                    ])
                    ->searchable(),
                SelectFilter::make('user_id')
                    ->relationship('user', 'name')
                    ->label(__('analytics.customer'))
                    ->searchable(),
                SelectFilter::make('channel_id')
                    ->relationship('channel', 'name')
                    ->label(__('analytics.channel'))
                    ->searchable(),
                Filter::make('created_at')
                    ->label(__('analytics.order_date_range'))
                    ->form([
                        SupportFlatpickr::makeRange('range', displayFormat: 'Y-m-d', format: 'Y-m-d'),
                    ])
                    ->indicateUsing(static fn (array $data): ?string => isset($data['range']['start'], $data['range']['end'])
                        ? __('analytics.order_date_range') . ': ' . $data['range']['start'] . ' → ' . $data['range']['end']
                        : null)
                    ->query(static fn (Builder $query, array $data): Builder => DateRangeFilter::apply(
                        $query,
                        $data['range'] ?? null,
                        'created_at',
                    )),
                Filter::make('high_value')
                    ->label(__('analytics.high_value_orders'))
                    ->query(static fn (Builder $query): Builder => $query->where('total', '>=', 500)),
                Filter::make('this_month')
                    ->label(__('analytics.this_month'))
                    ->query(static fn (Builder $query): Builder => $query->whereBetween('created_at', [
                        now()->startOfMonth(),
                        now()->endOfMonth(),
                    ])),
            ])
            ->groups([
                // Allow analysts to cluster orders by lifecycle stage.
                Group::make('status')
                    ->label(__('analytics.status'))
                    ->collapsible(),
                // Provide chronological grouping by month for period-over-period reviews.
                Group::make('created_at')
                    ->label(__('analytics.month'))
                    ->date()
                    ->getTitleFromRecordUsing(static function (Order $record): string {
                        // Translate the stored timestamp into a YYYY-MM label without triggering Filament's bool-only date() API.
                        return optional($record->created_at)?->translatedFormat('Y-m') ?? __('analytics.month');
                    })
                    ->getKeyFromRecordUsing(static function (Order $record): ?string {
                        // Normalise the grouping key to the same YYYY-MM string used for the display title.
                        return optional($record->created_at)?->format('Y-m');
                    }),
            ])
            ->defaultSort('created_at', 'desc')
            ->actions([
                // Deep-link into the order resource for detailed investigation of anomalies.
                ViewAction::make()
                    ->label(__('analytics.view_order'))
                    ->icon('heroicon-o-eye')
                    ->url(static fn (Order $record): string => OrderResource::getUrl('view', ['record' => $record]))
                    ->openUrlInNewTab(),
            ]);
    }

    public static function getRelations(): array
    {
        return [];
    }

    public static function getWidgets(): array
    {
        return [];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\AnalyticsDashboard::route('/'),
        ];
    }
}
