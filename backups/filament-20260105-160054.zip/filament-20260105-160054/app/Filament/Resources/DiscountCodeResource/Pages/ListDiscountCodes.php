<?php

declare(strict_types=1);

namespace App\Filament\Resources\DiscountCodeResource\Pages;

use App\Filament\Pages\Support\BaseListRecords;
use App\Filament\Resources\DiscountCodeResource;
use Filament\Actions;

final class ListDiscountCodes extends BaseListRecords
{
    protected static string $resource = DiscountCodeResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }
}
