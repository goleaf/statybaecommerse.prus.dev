<?php

declare(strict_types=1);

namespace App\Filament\Resources\CustomerGroupResource\RelationManagers;

use App\Filament\RelationManagers\Support\BaseRelationManager;
use Filament\Forms;
use Filament\Schemas\Schema;
use Filament\Tables;
use Filament\Tables\Table;

final class CampaignsRelationManager extends BaseRelationManager
{
    protected static string $relationship = 'targetCustomerGroups';

    protected static ?string $title = 'customer_groups.relation_campaigns';

    public function form(Schema $schema): Schema
    {
        return $schema
            ->schema([
                Forms\Components\TextInput::make('name')
                    ->required()
                    ->maxLength(255),
                Forms\Components\Select::make('status')
                    ->options([
                        'draft'     => __('campaigns.draft'),
                        'active'    => __('campaigns.active'),
                        'paused'    => __('campaigns.paused'),
                        'completed' => __('campaigns.completed'),
                    ]),
            ]);
    }

    public function table(Table $table): Table
    {
        // Configure the relation manager table to satisfy Filament v4's return type requirements.
        return $table
            ->recordTitleAttribute('name')
            ->columns([
                Tables\Columns\TextColumn::make('name')
                    ->label(__('campaigns.name'))
                    ->searchable()
                    ->sortable(),
                Tables\Columns\TextColumn::make('status')
                    ->label(__('campaigns.status'))
                    ->badge()
                    ->color(fn (string $state): string => match ($state) {
                        'active'    => 'success',
                        'draft'     => 'gray',
                        'paused'    => 'warning',
                        'completed' => 'info',
                        default     => 'gray',
                    }),
                Tables\Columns\TextColumn::make('budget')
                    ->label(__('campaigns.budget'))
                    ->money('EUR'),
                Tables\Columns\TextColumn::make('starts_at')
                    ->label(__('campaigns.starts_at'))
                    ->dateTime(),
                Tables\Columns\TextColumn::make('ends_at')
                    ->label(__('campaigns.ends_at'))
                    ->dateTime(),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('status')
                    ->options([
                        'draft'     => __('campaigns.draft'),
                        'active'    => __('campaigns.active'),
                        'paused'    => __('campaigns.paused'),
                        'completed' => __('campaigns.completed'),
                    ]),
            ])
            ->headerActions([
                RelationManagerRepeaterAction::make(),
                Tables\Actions\AttachAction::make()
                    ->label(__('customer_groups.attach_campaign')),
            ])
            ->actions([
                Tables\Actions\DetachAction::make()
                    ->label(__('customer_groups.detach_campaign')),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DetachBulkAction::make()
                        ->label(__('customer_groups.detach_selected')),
                ]),
            ]);
    }
}
