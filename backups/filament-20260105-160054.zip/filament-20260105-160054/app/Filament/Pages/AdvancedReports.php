<?php

declare(strict_types=1);

namespace App\Filament\Pages;

use BackedEnum;
use Filament\Pages\Page;
use Illuminate\Contracts\Support\Htmlable;

final class AdvancedReports extends Page
{
    /**
     * Aligns the navigation icon with Filament's BackedEnum-aware union expectations while providing
     * explicit PHPDoc for compatible union typing.
     */
    //    protected static BackedEnum|string|null $navigationIcon = 'heroicon-o-chart-bar-square';
    public static function getNavigationIcon(): BackedEnum|Htmlable|string|null
    {
        return 'heroicon-o-chart-bar-square';
    }

    public static function getNavigationGroup(): BackedEnum|string|null
    {
        return 'Analytics'; // Ensure advanced analytics live with the rest of the reporting suite.
    }

    protected static ?string $title = 'Advanced Reports';

    protected static ?string $slug = 'advanced-reports';

    protected string $view = 'filament.pages.advanced-reports';

    public static function shouldRegisterNavigation(): bool
    {
        return false;
    }
}
